# Updating the Docs
Use the Node script [update-wpd-docs](https://github.com/MarcelGerber/update-wpd-docs) to update the `css.json` contents:
```
[sudo] node update-wpd-docs --exclude-vendor-prefixed --output <bracketsRepo>/src/extensions/default/WebPlatformDocs/css.json
```
