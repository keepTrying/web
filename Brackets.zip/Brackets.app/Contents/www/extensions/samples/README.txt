This directory contains extensions that should be disabled by default, but 
that we want to add to the repo. This might include things like examples and
test cases.

(README also serves as a dummy file so this directory can be added to git.)
